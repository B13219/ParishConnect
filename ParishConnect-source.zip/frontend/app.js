const API_BASE = "http://127.0.0.1:8003/api/v1";

const state = {
  people: null,
  attendance: null,
  households: null,
  messages: null,
  stewardship: null,
  peopleFilters: {
    query: "",
    memberStatus: "all",
    visitorStatus: "all",
  },
};

const sections = ["people", "attendance", "households", "messages", "stewardship"];
const navSections = ["overview", "people", "attendance", "households", "messages", "stewardship"];

const formatCurrency = (amount, currency = "TZS") =>
  `${Number(amount || 0).toLocaleString()} ${currency}`;

const formatDateTime = (value) => (value ? new Date(value).toLocaleString() : "Not set");

const setStatus = (text, kind = "") => {
  const el = document.querySelector("#connectionStatus");
  el.textContent = text;
  el.className = `status-pill ${kind}`.trim();
};

const setBusy = (busy) => {
  document.querySelectorAll("button").forEach((button) => {
    button.disabled = busy;
  });
};

const fetchJson = async (path) => {
  const response = await fetch(`${API_BASE}${path}`);
  if (!response.ok) {
    throw new Error(`${path} returned ${response.status}`);
  }
  return response.json();
};

const sendJson = async (path, method, payload = null) => {
  const response = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
    },
    body: payload ? JSON.stringify(payload) : null,
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.detail || `${path} returned ${response.status}`);
  }
  return response.json();
};

const formPayload = (form) =>
  Object.fromEntries(
    Array.from(new FormData(form).entries()).map(([key, value]) => [
      key,
      typeof value === "string" && value.trim() === "" ? null : value,
    ]),
  );

const emptyState = (message) => `<div class="empty-state">${message}</div>`;

const setSkeletons = () => {
  [
    "#memberList",
    "#visitorList",
    "#eventList",
    "#checkInList",
    "#householdList",
    "#contributionBreakdown",
    "#messageList",
    "#contributionList",
  ].forEach((selector) => {
    document.querySelector(selector).innerHTML =
      '<div class="skeleton"></div><div class="skeleton"></div>';
  });
};

const row = ({ title, subtitle, tag, tone = "", action = "" }) => `
  <div class="row">
    <div>
      <strong>${title}</strong>
      <span>${subtitle}</span>
    </div>
    <div class="row-actions">
      <span class="tag ${tone}">${tag}</span>
      ${action}
    </div>
  </div>
`;

const personMatchesQuery = (person, query) => {
  if (!query) {
    return true;
  }
  const haystack = [
    person.name,
    person.first_name,
    person.last_name,
    person.phone,
    person.email,
    person.status,
    person.follow_up_status,
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  return haystack.includes(query.toLowerCase());
};

const memberLifecycleActions = (member) => {
  if (["transferred", "deceased", "discontinued"].includes(member.status)) {
    return "";
  }

  return `
    <button class="mini-button" data-member-status="${member.id}:transferred" type="button">Transfer</button>
    <button class="mini-button danger" data-member-status="${member.id}:deceased" type="button">Deceased</button>
    <button class="mini-button muted" data-member-status="${member.id}:discontinued" type="button">Discontinue</button>
  `;
};

const renderPeople = () => {
  const allMembers = state.people?.members || [];
  const allVisitors = state.people?.visitors || [];
  const members = allMembers.filter(
    (member) =>
      personMatchesQuery(member, state.peopleFilters.query) &&
      (state.peopleFilters.memberStatus === "all" ||
        member.status === state.peopleFilters.memberStatus),
  );
  const visitors = allVisitors.filter(
    (visitor) =>
      personMatchesQuery(visitor, state.peopleFilters.query) &&
      (state.peopleFilters.visitorStatus === "all" ||
        visitor.follow_up_status === state.peopleFilters.visitorStatus),
  );

  document.querySelector("#memberCount").textContent = allMembers.length;
  document.querySelector("#visitorCount").textContent = allVisitors.length;
  document.querySelector("#memberList").innerHTML =
    members
      .map((member) =>
        row({
          title: member.name,
          subtitle: [member.phone || "No phone", member.email || "No email"].join(" - "),
          tag: member.status,
          tone: member.status === "active" ? "green" : "muted",
          action: `
            <button class="mini-button" data-edit-member="${member.id}" type="button">Edit</button>
            ${memberLifecycleActions(member)}
          `,
        }),
      )
      .join("") || emptyState("No members found.");
  document.querySelector("#visitorList").innerHTML =
    visitors
      .map((visitor) =>
        row({
          title: visitor.name,
          subtitle: [visitor.phone || "No phone", visitor.email || "No email"].join(" - "),
          tag: visitor.follow_up_status,
          tone: "amber",
          action: `
            <button class="mini-button" data-edit-visitor="${visitor.id}" type="button">Edit</button>
            ${
              visitor.converted_member_id
                ? ""
                : `<button class="mini-button" data-convert-visitor="${visitor.id}" type="button">Convert</button>`
            }
          `,
        }),
      )
      .join("") || emptyState("No visitors found.");

  document.querySelectorAll("[data-edit-member]").forEach((button) => {
    button.addEventListener("click", () => openPersonDialog("member", button.dataset.editMember));
  });
  document.querySelectorAll("[data-edit-visitor]").forEach((button) => {
    button.addEventListener("click", () => openPersonDialog("visitor", button.dataset.editVisitor));
  });
  document.querySelectorAll("[data-convert-visitor]").forEach((button) => {
    button.addEventListener("click", () => convertVisitor(button.dataset.convertVisitor));
  });
  document.querySelectorAll("[data-member-status]").forEach((button) => {
    button.addEventListener("click", () => {
      const [memberId, lifecycleStatus] = button.dataset.memberStatus.split(":");
      updateMemberStatus(memberId, lifecycleStatus);
    });
  });
  renderCheckInPersonOptions();
  renderHouseholdMemberOptions();
  renderContributionMemberOptions();
};

const renderAttendance = () => {
  const events = state.attendance?.events || [];
  const recentCheckIns = state.attendance?.recent_check_ins || [];

  document.querySelector("#checkInCount").textContent = state.attendance?.total_check_ins || 0;
  document.querySelector("#eventList").innerHTML =
    events
      .map((event) =>
        row({
          title: event.name,
          subtitle: `${formatDateTime(event.starts_at)} - ${
            event.location || "No location"
          } - QR ${event.qr_active ? "open" : "closed"}`,
          tag: `${event.check_ins || 0} check-ins`,
          tone: event.qr_active ? "green" : "",
          action: `<button class="mini-button" data-event-qr="${event.id}" type="button">QR</button>`,
        }),
      )
      .join("") || emptyState("No upcoming events found.");
  document.querySelector("#checkInList").innerHTML =
    recentCheckIns
      .map((checkIn) =>
        row({
          title: checkIn.person_name,
          subtitle: `${checkIn.event_name} - ${formatDateTime(checkIn.checked_in_at)}`,
          tag: checkIn.person_type,
          tone: checkIn.check_in_method === "qr" ? "green" : "amber",
        }),
      )
      .join("") || emptyState("No recent check-ins found.");
  document.querySelectorAll("[data-event-qr]").forEach((button) => {
    button.addEventListener("click", () => showQrToken(button.dataset.eventQr));
  });
  renderCheckInEventOptions();
};

const renderHouseholds = () => {
  const households = state.households?.households || [];
  document.querySelector("#householdList").innerHTML =
    households
      .map((household) =>
        row({
          title: household.name,
          subtitle: `${household.people.length} people - ${
            household.primary_contact || household.primary_phone || "No primary contact"
          }`,
          tag: "household",
          action: household.people
            .map(
              (person) =>
                `<span class="tag ${person.can_self_check_in ? "green" : "muted"}">${
                  person.name
                } (${person.relationship})</span>`,
            )
            .join(""),
        }),
      )
      .join("") || emptyState("No households found.");
  renderHouseholdOptions();
};

const renderMessages = () => {
  const messages = state.messages?.messages || [];

  document.querySelector("#messageList").innerHTML =
    messages
      .map((message) =>
        row({
          title: message.subject || "Untitled message",
          subtitle: `${message.channel.toUpperCase()} - ${message.audience_type}`,
          tag: message.status,
          tone: message.status === "sent" ? "green" : "amber",
        }),
      )
      .join("") || emptyState("No messages found.");
};

const renderStewardship = () => {
  const finance = state.stewardship || {};
  const latest = finance.latest || [];
  const byType = finance.by_type || [];
  const formattedTotal = formatCurrency(finance.total_amount, finance.currency);

  document.querySelector("#contributionTotal").textContent = formattedTotal;
  document.querySelector("#financeTotal").textContent = formattedTotal;
  document.querySelector("#contributionCount").textContent = `${finance.contribution_count || 0} records`;
  document.querySelector("#contributionBreakdown").innerHTML =
    byType
      .map(
        (item) => `
          <div class="finance-chip">
            <span>${item.type}</span>
            <strong>${formatCurrency(item.amount, item.currency)}</strong>
          </div>
        `,
      )
      .join("") || emptyState("No contribution breakdown yet.");
  document.querySelector("#contributionList").innerHTML =
    latest
      .map((contribution) =>
        row({
          title: `${contribution.type} - ${formatCurrency(
            contribution.amount,
            contribution.currency,
          )}`,
          subtitle: `${contribution.member_name || "Anonymous / Visitor"} - ${formatDateTime(
            contribution.received_at,
          )}`,
          tag: contribution.currency,
          tone: "green",
        }),
      )
      .join("") || emptyState("No contribution records found.");
  renderContributionMemberOptions();
};

const loadSection = async (section) => {
  if (section === "people") {
    state.people = await fetchJson("/members/");
    renderPeople();
  }
  if (section === "attendance") {
    state.attendance = await fetchJson("/attendance/");
    renderAttendance();
  }
  if (section === "households") {
    state.households = await fetchJson("/members/households");
    renderHouseholds();
  }
  if (section === "messages") {
    state.messages = await fetchJson("/messages/");
    renderMessages();
  }
  if (section === "stewardship") {
    state.stewardship = await fetchJson("/stewardship/");
    renderStewardship();
  }
};

const loadDashboard = async () => {
  try {
    setBusy(true);
    setStatus("Connecting");
    setSkeletons();
    await Promise.all(sections.map(loadSection));
    setStatus("API Connected", "ok");
  } catch (error) {
    console.error(error);
    setStatus("API Offline", "error");
  } finally {
    setBusy(false);
  }
};

const renderCheckInEventOptions = () => {
  const select = document.querySelector("#checkInEventSelect");
  const events = state.attendance?.events || [];
  select.innerHTML =
    events
      .map((event) => `<option value="${event.id}">${event.name}</option>`)
      .join("") || '<option value="">Create an event first</option>';
};

const renderCheckInPersonOptions = () => {
  const select = document.querySelector("#checkInPersonSelect");
  const personType = document.querySelector("#checkInPersonType").value;
  const people =
    personType === "member" ? state.people?.members || [] : state.people?.visitors || [];
  select.innerHTML =
    people
      .filter((person) => person.status !== "deceased" && person.follow_up_status !== "converted")
      .map((person) => `<option value="${person.id}">${person.name}</option>`)
      .join("") || `<option value="">No ${personType}s available</option>`;
};

const renderHouseholdMemberOptions = () => {
  const select = document.querySelector("#householdPrimaryMember");
  const members = state.people?.members || [];
  select.innerHTML =
    '<option value="">No primary adult</option>' +
    members
      .filter((member) => member.status === "active")
      .map((member) => `<option value="${member.id}">${member.name}</option>`)
      .join("");
};

const renderHouseholdOptions = () => {
  const select = document.querySelector("#dependentHouseholdSelect");
  const households = state.households?.households || [];
  select.innerHTML =
    households
      .map((household) => `<option value="${household.id}">${household.name}</option>`)
      .join("") || '<option value="">Create a household first</option>';
};

const renderContributionMemberOptions = () => {
  const select = document.querySelector("#contributionMemberSelect");
  if (!select) {
    return;
  }
  const members = state.people?.members || [];
  select.innerHTML =
    '<option value="">Anonymous / visitor</option>' +
    members
      .filter((member) => member.status === "active")
      .map((member) => `<option value="${member.id}">${member.name}</option>`)
      .join("");
};

const dateInputToIso = (value) => (value ? new Date(value).toISOString() : null);

const scanUrlFor = (eventId, token) =>
  `${window.location.origin}/scan.html?event_id=${encodeURIComponent(eventId)}&token=${encodeURIComponent(
    token,
  )}`;

const eventPayload = (form) => {
  const payload = formPayload(form);
  if (payload.starts_at) {
    payload.starts_at = dateInputToIso(payload.starts_at);
  }
  payload.qr_opens_at = dateInputToIso(payload.qr_opens_at);
  payload.qr_closes_at = dateInputToIso(payload.qr_closes_at);
  payload.qr_rotation_seconds = Number(payload.qr_rotation_seconds || 60);
  return payload;
};

const showQrToken = async (eventId) => {
  const panel = document.querySelector("#qrTokenPanel");
  try {
    setBusy(true);
    setStatus("Loading QR");
    const data = await fetchJson(`/attendance/events/${eventId}/qr-token`);
    const scanUrl = data.token ? scanUrlFor(eventId, data.token) : "";
    const qrImageUrl = data.token
      ? `${API_BASE}/attendance/events/${eventId}/qr-code.svg?data=${encodeURIComponent(scanUrl)}`
      : "";
    panel.innerHTML = `
      <div class="qr-display">
        <div class="qr-code-frame">
          ${
            qrImageUrl
              ? `<img src="${qrImageUrl}" alt="Attendance QR code for ${data.event.name}">`
              : `<span>QR opens at ${formatDateTime(data.opens_at)}</span>`
          }
        </div>
        <div>
          <strong>${data.event.name}</strong>
          <span>${data.active ? "QR attendance is open" : "QR attendance is closed"}</span>
          <code>${data.token || "Token unavailable until the attendance window opens."}</code>
          ${scanUrl ? `<a class="mini-button link-button" href="${scanUrl}" target="_blank" rel="noreferrer">Open scan page</a>` : ""}
        </div>
      </div>
      <div class="qr-meta">
        <span>Opens: ${formatDateTime(data.opens_at)}</span>
        <span>Closes: ${formatDateTime(data.closes_at)}</span>
        <span>Rotates: ${data.rotation_seconds}s</span>
        <span>Expires: ${formatDateTime(data.expires_at)}</span>
      </div>
    `;
    setStatus(data.active ? "QR Ready" : "QR Scheduled", data.active ? "ok" : "");
  } catch (error) {
    console.error(error);
    panel.innerHTML = `<span>${error.message || "QR token failed"}</span>`;
    setStatus(error.message || "QR failed", "error");
  } finally {
    setBusy(false);
  }
};

const submitEventForm = async (form) => {
  try {
    setBusy(true);
    setStatus("Creating event");
    await sendJson("/attendance/events", "POST", eventPayload(form));
    form.reset();
    await loadSection("attendance");
    setStatus("Event created", "ok");
  } catch (error) {
    console.error(error);
    setStatus(error.message || "Event failed", "error");
  } finally {
    setBusy(false);
  }
};

const submitCheckInForm = async (form) => {
  try {
    setBusy(true);
    setStatus("Checking in");
    await sendJson("/attendance/check-ins", "POST", formPayload(form));
    await loadSection("attendance");
    setStatus("Check-in recorded", "ok");
  } catch (error) {
    console.error(error);
    setStatus(error.message || "Check-in failed", "error");
  } finally {
    setBusy(false);
  }
};

const submitContributionForm = async (form) => {
  const payload = formPayload(form);
  payload.amount = Number(payload.amount || 0);

  try {
    setBusy(true);
    setStatus("Recording contribution");
    await sendJson("/stewardship/contributions", "POST", payload);
    form.reset();
    await loadSection("stewardship");
    setStatus("Contribution recorded", "ok");
  } catch (error) {
    console.error(error);
    setStatus(error.message || "Contribution failed", "error");
  } finally {
    setBusy(false);
  }
};

const submitHouseholdForm = async (form) => {
  try {
    setBusy(true);
    setStatus("Creating household");
    await sendJson("/members/households", "POST", formPayload(form));
    form.reset();
    await loadSection("households");
    setStatus("Household created", "ok");
  } catch (error) {
    console.error(error);
    setStatus(error.message || "Household failed", "error");
  } finally {
    setBusy(false);
  }
};

const submitDependentForm = async (form) => {
  const payload = formPayload(form);
  const householdId = payload.household_id;
  delete payload.household_id;
  payload.can_self_check_in = false;

  try {
    setBusy(true);
    setStatus("Adding dependent");
    await sendJson(`/members/households/${householdId}/people`, "POST", payload);
    form.reset();
    form.elements.relationship.value = "child";
    await loadSection("households");
    setStatus("Dependent added", "ok");
  } catch (error) {
    console.error(error);
    setStatus(error.message || "Dependent failed", "error");
  } finally {
    setBusy(false);
  }
};

const submitPersonForm = async (form, path, successMessage) => {
  try {
    setBusy(true);
    setStatus("Saving");
    await sendJson(path, "POST", formPayload(form));
    form.reset();
    await loadSection("people");
    setStatus(successMessage, "ok");
  } catch (error) {
    console.error(error);
    setStatus(error.message || "Save failed", "error");
  } finally {
    setBusy(false);
  }
};

const convertVisitor = async (visitorId) => {
  try {
    setBusy(true);
    setStatus("Converting");
    await sendJson(`/members/visitors/${visitorId}/convert`, "POST");
    await loadSection("people");
    setStatus("Visitor converted", "ok");
  } catch (error) {
    console.error(error);
    setStatus(error.message || "Convert failed", "error");
  } finally {
    setBusy(false);
  }
};

const updateMemberStatus = async (memberId, membershipStatus) => {
  const labels = {
    transferred: "mark this member as transferred to another church",
    deceased: "mark this member as deceased",
    discontinued: "mark this member as discontinued",
  };

  const confirmed = window.confirm(`Are you sure you want to ${labels[membershipStatus]}?`);
  if (!confirmed) {
    return;
  }

  try {
    setBusy(true);
    setStatus("Updating member");
    await sendJson(`/members/${memberId}`, "PATCH", { membership_status: membershipStatus });
    await loadSection("people");
    setStatus("Member updated", "ok");
  } catch (error) {
    console.error(error);
    setStatus(error.message || "Update failed", "error");
  } finally {
    setBusy(false);
  }
};

const statusOptions = {
  member: ["active", "transferred", "deceased", "discontinued"],
  visitor: ["new", "contacted", "converted"],
};

const openPersonDialog = (type, personId) => {
  const person =
    type === "member"
      ? state.people.members.find((member) => member.id === personId)
      : state.people.visitors.find((visitor) => visitor.id === personId);
  if (!person) {
    setStatus("Record not found", "error");
    return;
  }

  const dialog = document.querySelector("#personDialog");
  const form = document.querySelector("#personEditForm");
  const statusField = document.querySelector("#personStatusField");
  const statusValue = type === "member" ? person.status : person.follow_up_status;

  document.querySelector("#personDialogType").textContent = type === "member" ? "Member" : "Visitor";
  document.querySelector("#personDialogTitle").textContent = `Edit ${person.name}`;
  statusField.innerHTML = statusOptions[type]
    .map((option) => `<option value="${option}">${option}</option>`)
    .join("");

  form.elements.id.value = person.id;
  form.elements.type.value = type;
  form.elements.first_name.value = person.first_name || "";
  form.elements.last_name.value = person.last_name || "";
  form.elements.phone.value = person.phone || "";
  form.elements.email.value = person.email || "";
  form.elements.status.value = statusValue;

  dialog.showModal();
};

const submitEditForm = async (form) => {
  const payload = formPayload(form);
  const type = payload.type;
  const id = payload.id;
  const statusKey = type === "member" ? "membership_status" : "follow_up_status";
  const path = type === "member" ? `/members/${id}` : `/members/visitors/${id}`;

  delete payload.id;
  delete payload.type;
  payload[statusKey] = payload.status;
  delete payload.status;

  try {
    setBusy(true);
    setStatus("Saving changes");
    await sendJson(path, "PATCH", payload);
    document.querySelector("#personDialog").close();
    await loadSection("people");
    setStatus("Record updated", "ok");
  } catch (error) {
    console.error(error);
    setStatus(error.message || "Update failed", "error");
  } finally {
    setBusy(false);
  }
};

const updatePeopleFilters = () => {
  state.peopleFilters.query = document.querySelector("#peopleSearch").value.trim();
  state.peopleFilters.memberStatus = document.querySelector("#memberStatusFilter").value;
  state.peopleFilters.visitorStatus = document.querySelector("#visitorStatusFilter").value;
  renderPeople();
};

const setActiveNav = (sectionId) => {
  document.querySelectorAll("[data-section-link]").forEach((link) => {
    link.classList.toggle("active", link.dataset.sectionLink === sectionId);
  });
};

const setupStickyNavigation = () => {
  const observer = new IntersectionObserver(
    (entries) => {
      const visible = entries
        .filter((entry) => entry.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) {
        setActiveNav(visible.target.id);
      }
    },
    {
      rootMargin: "-15% 0px -65% 0px",
      threshold: [0.1, 0.25, 0.5, 0.75],
    },
  );

  navSections.forEach((sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      observer.observe(section);
    }
  });

  document.querySelectorAll("[data-section-link]").forEach((link) => {
    link.addEventListener("click", () => setActiveNav(link.dataset.sectionLink));
  });
};

document.querySelectorAll("[data-refresh]").forEach((button) => {
  button.addEventListener("click", async () => {
    try {
      setBusy(true);
      setStatus("Refreshing");
      await loadSection(button.dataset.refresh);
      setStatus("API Connected", "ok");
    } catch (error) {
      console.error(error);
      setStatus("API Offline", "error");
    } finally {
      setBusy(false);
    }
  });
});

document.querySelector("#refreshAll").addEventListener("click", loadDashboard);
document.querySelector("#memberForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitPersonForm(event.currentTarget, "/members/", "Member added");
});
document.querySelector("#visitorForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitPersonForm(event.currentTarget, "/members/visitors", "Visitor added");
});
document.querySelector("#eventForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitEventForm(event.currentTarget);
});
document.querySelector("#checkInForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitCheckInForm(event.currentTarget);
});
document.querySelector("#contributionForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitContributionForm(event.currentTarget);
});
document.querySelector("#householdForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitHouseholdForm(event.currentTarget);
});
document.querySelector("#dependentForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitDependentForm(event.currentTarget);
});
document.querySelector("#checkInPersonType").addEventListener("change", renderCheckInPersonOptions);
document.querySelector("#personEditForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitEditForm(event.currentTarget);
});
document.querySelector("#closePersonDialog").addEventListener("click", () => {
  document.querySelector("#personDialog").close();
});
document.querySelector("#peopleSearch").addEventListener("input", updatePeopleFilters);
document.querySelector("#memberStatusFilter").addEventListener("change", updatePeopleFilters);
document.querySelector("#visitorStatusFilter").addEventListener("change", updatePeopleFilters);

setupStickyNavigation();
loadDashboard();

# ParishConnect API

## Local Setup

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
uvicorn app.main:app --reload
```

## Local PostgreSQL

Start a local demo database with Docker:

```powershell
docker compose up -d postgres
```

Apply the database schema:

```powershell
alembic upgrade head
```

Load safe sample data:

```powershell
python -m app.scripts.seed_demo
```

## Immediate Demo Database Fallback

If Docker Desktop or PostgreSQL is not available, create a local SQLite demo database with the same SQLAlchemy models:

```powershell
python -m app.scripts.init_demo_sqlite
.\run-demo.ps1
```

This is for local presentation only. PostgreSQL remains the intended development and production database.

Health check:

```text
GET /health
```

Product overview:

```text
GET /api/v1/
```

Expected response:

```json
{
  "status": "ok",
  "service": "ParishConnect API",
  "version": "0.1.0"
}
```

## Next Backend Steps

1. Start PostgreSQL locally or point `PARISHCONNECT_DATABASE_URL` at a hosted database.
2. Run the initial migration with `alembic upgrade head`.
3. Implement identity and role-based access control.
4. Add CRUD endpoints for branch, member, visitor, event, and attendance records.
5. Add import pipeline for CSV and Excel migration.

## Database

The initial schema is captured in:

```text
alembic/versions/20260710_0001_initial_schema.py
```

It creates the first 11 tables for branches, users, roles, members, visitors, ministries, events, attendance, messages, and contributions.

## Demo Data Safety

The seed script uses fake names, fake `.test` emails, and fake phone numbers. Do not import real church records until authentication, role permissions, backups, and import validation are in place.

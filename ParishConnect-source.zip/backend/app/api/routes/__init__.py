from fastapi import APIRouter

from app.api.routes.attendance import router as attendance_router
from app.api.routes.members import router as members_router
from app.api.routes.messages import router as messages_router
from app.api.routes.root import router as root_router
from app.api.routes.stewardship import router as stewardship_router

router = APIRouter()
router.include_router(root_router, tags=["product"])
router.include_router(members_router, prefix="/members", tags=["members"])
router.include_router(attendance_router, prefix="/attendance", tags=["attendance"])
router.include_router(messages_router, prefix="/messages", tags=["messages"])
router.include_router(stewardship_router, prefix="/stewardship", tags=["stewardship"])


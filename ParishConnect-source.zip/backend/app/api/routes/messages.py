from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models import Message

router = APIRouter()


@router.get("/")
def list_messages(db: Session = Depends(get_db)) -> dict[str, object]:
    messages = db.scalars(select(Message).order_by(Message.created_at.desc()).limit(20)).all()

    return {
        "module": "messages",
        "status": "demo-data-ready",
        "messages": [
            {
                "id": str(message.id),
                "channel": message.channel,
                "subject": message.subject,
                "status": message.status,
                "audience_type": message.audience_type,
            }
            for message in messages
        ],
    }

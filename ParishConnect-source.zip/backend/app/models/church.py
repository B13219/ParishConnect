from datetime import datetime
from decimal import Decimal
from uuid import UUID

from sqlalchemy import ForeignKey, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, IdMixin, TimestampMixin, utc_now


class Branch(IdMixin, TimestampMixin, Base):
    __tablename__ = "branches"

    name: Mapped[str] = mapped_column(String(160), nullable=False)
    location: Mapped[str | None] = mapped_column(String(240))
    contact_phone: Mapped[str | None] = mapped_column(String(40))


class User(IdMixin, TimestampMixin, Base):
    __tablename__ = "users"

    branch_id: Mapped[UUID | None] = mapped_column(ForeignKey("branches.id"))
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    phone: Mapped[str | None] = mapped_column(String(40))
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(String(40), default="active")


class Role(IdMixin, TimestampMixin, Base):
    __tablename__ = "roles"

    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(Text)


class UserRole(Base):
    __tablename__ = "user_roles"

    user_id: Mapped[UUID] = mapped_column(ForeignKey("users.id"), primary_key=True)
    role_id: Mapped[UUID] = mapped_column(ForeignKey("roles.id"), primary_key=True)


class Member(IdMixin, TimestampMixin, Base):
    __tablename__ = "members"

    branch_id: Mapped[UUID] = mapped_column(ForeignKey("branches.id"), nullable=False)
    first_name: Mapped[str] = mapped_column(String(100), nullable=False)
    last_name: Mapped[str] = mapped_column(String(100), nullable=False)
    phone: Mapped[str | None] = mapped_column(String(40))
    email: Mapped[str | None] = mapped_column(String(255))
    membership_status: Mapped[str] = mapped_column(String(40), default="active")
    joined_at: Mapped[datetime | None]


class Visitor(IdMixin, TimestampMixin, Base):
    __tablename__ = "visitors"

    branch_id: Mapped[UUID] = mapped_column(ForeignKey("branches.id"), nullable=False)
    first_name: Mapped[str] = mapped_column(String(100), nullable=False)
    last_name: Mapped[str] = mapped_column(String(100), nullable=False)
    phone: Mapped[str | None] = mapped_column(String(40))
    email: Mapped[str | None] = mapped_column(String(255))
    follow_up_status: Mapped[str] = mapped_column(String(40), default="new")
    converted_member_id: Mapped[UUID | None] = mapped_column(ForeignKey("members.id"))


class Household(IdMixin, TimestampMixin, Base):
    __tablename__ = "households"

    branch_id: Mapped[UUID] = mapped_column(ForeignKey("branches.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    primary_member_id: Mapped[UUID | None] = mapped_column(ForeignKey("members.id"))
    primary_phone: Mapped[str | None] = mapped_column(String(40))
    notes: Mapped[str | None] = mapped_column(Text)


class HouseholdPerson(IdMixin, TimestampMixin, Base):
    __tablename__ = "household_people"

    household_id: Mapped[UUID] = mapped_column(ForeignKey("households.id"), nullable=False)
    member_id: Mapped[UUID | None] = mapped_column(ForeignKey("members.id"))
    visitor_id: Mapped[UUID | None] = mapped_column(ForeignKey("visitors.id"))
    first_name: Mapped[str | None] = mapped_column(String(100))
    last_name: Mapped[str | None] = mapped_column(String(100))
    person_type: Mapped[str] = mapped_column(String(40), nullable=False)
    relationship: Mapped[str] = mapped_column(String(60), nullable=False)
    can_self_check_in: Mapped[str] = mapped_column(String(5), default="yes")
    status: Mapped[str] = mapped_column(String(40), default="active")


class Ministry(IdMixin, TimestampMixin, Base):
    __tablename__ = "ministries"

    branch_id: Mapped[UUID] = mapped_column(ForeignKey("branches.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    leader_member_id: Mapped[UUID | None] = mapped_column(ForeignKey("members.id"))


class Event(IdMixin, TimestampMixin, Base):
    __tablename__ = "events"

    branch_id: Mapped[UUID] = mapped_column(ForeignKey("branches.id"), nullable=False)
    ministry_id: Mapped[UUID | None] = mapped_column(ForeignKey("ministries.id"))
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    event_type: Mapped[str] = mapped_column(String(80), default="service")
    starts_at: Mapped[datetime]
    ends_at: Mapped[datetime | None]
    location: Mapped[str | None] = mapped_column(String(240))
    qr_opens_at: Mapped[datetime | None]
    qr_closes_at: Mapped[datetime | None]
    qr_rotation_seconds: Mapped[int] = mapped_column(default=60)


class AttendanceRecord(IdMixin, TimestampMixin, Base):
    __tablename__ = "attendance_records"

    branch_id: Mapped[UUID] = mapped_column(ForeignKey("branches.id"), nullable=False)
    event_id: Mapped[UUID] = mapped_column(ForeignKey("events.id"), nullable=False)
    person_type: Mapped[str] = mapped_column(String(20), nullable=False)
    member_id: Mapped[UUID | None] = mapped_column(ForeignKey("members.id"))
    visitor_id: Mapped[UUID | None] = mapped_column(ForeignKey("visitors.id"))
    household_person_id: Mapped[UUID | None] = mapped_column(ForeignKey("household_people.id"))
    checked_in_by: Mapped[UUID | None] = mapped_column(ForeignKey("users.id"))
    check_in_method: Mapped[str] = mapped_column(String(40), default="manual")
    checked_in_at: Mapped[datetime] = mapped_column(default=utc_now)
    corrected_at: Mapped[datetime | None]


class Message(IdMixin, TimestampMixin, Base):
    __tablename__ = "messages"

    branch_id: Mapped[UUID] = mapped_column(ForeignKey("branches.id"), nullable=False)
    sender_user_id: Mapped[UUID | None] = mapped_column(ForeignKey("users.id"))
    channel: Mapped[str] = mapped_column(String(40), nullable=False)
    subject: Mapped[str | None] = mapped_column(String(160))
    body: Mapped[str] = mapped_column(Text, nullable=False)
    audience_type: Mapped[str] = mapped_column(String(80), default="all_members")
    status: Mapped[str] = mapped_column(String(40), default="draft")
    scheduled_at: Mapped[datetime | None]
    sent_at: Mapped[datetime | None]


class Contribution(IdMixin, TimestampMixin, Base):
    __tablename__ = "contributions"

    branch_id: Mapped[UUID] = mapped_column(ForeignKey("branches.id"), nullable=False)
    member_id: Mapped[UUID | None] = mapped_column(ForeignKey("members.id"))
    contribution_type: Mapped[str] = mapped_column(String(80), nullable=False)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    received_at: Mapped[datetime] = mapped_column(default=utc_now)
    recorded_by: Mapped[UUID | None] = mapped_column(ForeignKey("users.id"))
    notes: Mapped[str | None] = mapped_column(Text)

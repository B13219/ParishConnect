from app.db.base import Base
from app.models import (
    AttendanceRecord,
    Branch,
    Contribution,
    Event,
    Member,
    Message,
    Ministry,
    Role,
    User,
    UserRole,
    Visitor,
)


def test_initial_database_tables_are_registered() -> None:
    expected_tables = {
        "attendance_records",
        "branches",
        "contributions",
        "events",
        "members",
        "messages",
        "ministries",
        "roles",
        "user_roles",
        "users",
        "visitors",
    }

    assert expected_tables.issubset(Base.metadata.tables.keys())


def test_models_import_for_migration_discovery() -> None:
    assert all(
        [
            AttendanceRecord,
            Branch,
            Contribution,
            Event,
            Member,
            Message,
            Ministry,
            Role,
            User,
            UserRole,
            Visitor,
        ]
    )


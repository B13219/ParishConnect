from collections.abc import Generator

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import create_app
from app.models import Branch, Member


def build_client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    Base.metadata.create_all(engine)

    with TestingSessionLocal() as db:
        branch = Branch(name="Test Parish", location="Test City")
        db.add(branch)
        db.flush()
        db.add(Member(branch_id=branch.id, first_name="Ada", last_name="Member"))
        db.commit()

    app = create_app()

    def override_get_db() -> Generator[Session, None, None]:
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app)


def test_record_contribution_and_summary_breakdown() -> None:
    client = build_client()
    member_id = client.get("/api/v1/members/").json()["members"][0]["id"]

    response = client.post(
        "/api/v1/stewardship/contributions",
        json={
            "member_id": member_id,
            "contribution_type": "tithe",
            "amount": "125000.00",
            "currency": "tzs",
            "notes": "Sunday envelope",
        },
    )

    assert response.status_code == 201
    contribution = response.json()
    assert contribution["member_name"] == "Ada Member"
    assert contribution["currency"] == "TZS"

    summary = client.get("/api/v1/stewardship/").json()
    assert summary["total_amount"] == "125000.00"
    assert summary["contribution_count"] == 1
    assert summary["by_type"][0]["type"] == "tithe"
    assert summary["latest"][0]["notes"] == "Sunday envelope"


def test_reject_negative_contribution() -> None:
    client = build_client()

    response = client.post(
        "/api/v1/stewardship/contributions",
        json={"contribution_type": "offering", "amount": "-5.00"},
    )

    assert response.status_code == 422

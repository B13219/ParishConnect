from collections.abc import Generator

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import create_app
from app.models import Branch, Member, Visitor


def build_client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    Base.metadata.create_all(engine)

    with TestingSessionLocal() as db:
        branch = Branch(name="Test Parish", location="Test City")
        db.add(branch)
        db.flush()
        db.add_all(
            [
                Member(branch_id=branch.id, first_name="Ada", last_name="Member"),
                Visitor(branch_id=branch.id, first_name="Ben", last_name="Visitor"),
            ]
        )
        db.commit()

    app = create_app()

    def override_get_db() -> Generator[Session, None, None]:
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    return TestClient(app)


def test_create_event_and_check_in_member() -> None:
    client = build_client()
    people = client.get("/api/v1/members/").json()
    member_id = people["members"][0]["id"]

    event_response = client.post(
        "/api/v1/attendance/events",
        json={"name": "Sunday Service", "event_type": "service", "location": "Main Hall"},
    )

    assert event_response.status_code == 201
    event = event_response.json()
    assert event["name"] == "Sunday Service"

    check_in_response = client.post(
        "/api/v1/attendance/check-ins",
        json={"event_id": event["id"], "person_type": "member", "person_id": member_id},
    )

    assert check_in_response.status_code == 201
    assert check_in_response.json()["person_name"] == "Ada Member"

    duplicate_response = client.post(
        "/api/v1/attendance/check-ins",
        json={"event_id": event["id"], "person_type": "member", "person_id": member_id},
    )

    assert duplicate_response.status_code == 409


def test_create_visitor_check_in() -> None:
    client = build_client()
    people = client.get("/api/v1/members/").json()
    visitor_id = people["visitors"][0]["id"]
    event_id = client.post("/api/v1/attendance/events", json={"name": "Youth Meeting"}).json()["id"]

    check_in_response = client.post(
        "/api/v1/attendance/check-ins",
        json={"event_id": event_id, "person_type": "visitor", "person_id": visitor_id},
    )

    assert check_in_response.status_code == 201
    assert check_in_response.json()["person_name"] == "Ben Visitor"


def test_qr_check_in_member() -> None:
    client = build_client()
    people = client.get("/api/v1/members/").json()
    member_id = people["members"][0]["id"]
    event = client.post("/api/v1/attendance/events", json={"name": "QR Service"}).json()

    token_response = client.get(f"/api/v1/attendance/events/{event['id']}/qr-token")

    assert token_response.status_code == 200
    token = token_response.json()["token"]
    assert token is not None

    check_in_response = client.post(
        "/api/v1/attendance/qr-check-ins",
        json={
            "event_id": event["id"],
            "qr_token": token,
            "person_type": "member",
            "person_id": member_id,
        },
    )

    assert check_in_response.status_code == 201
    assert check_in_response.json()["check_in_method"] == "qr"


def test_qr_code_svg_endpoint() -> None:
    client = build_client()
    event = client.post("/api/v1/attendance/events", json={"name": "QR Display"}).json()
    response = client.get(
        f"/api/v1/attendance/events/{event['id']}/qr-code.svg",
        params={"data": "http://127.0.0.1:5173/scan.html?event_id=demo&token=demo"},
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("image/svg+xml")
    assert "<svg" in response.text
    assert "<rect" in response.text


def test_qr_check_in_household_dependent() -> None:
    client = build_client()
    people = client.get("/api/v1/members/").json()
    member_id = people["members"][0]["id"]
    household = client.post(
        "/api/v1/members/households",
        json={"name": "Ada Household", "primary_member_id": member_id},
    ).json()
    dependent = client.post(
        f"/api/v1/members/households/{household['id']}/people",
        json={
            "first_name": "Chris",
            "last_name": "Child",
            "person_type": "child",
            "relationship": "child",
            "can_self_check_in": False,
        },
    ).json()
    event = client.post("/api/v1/attendance/events", json={"name": "Family Sunday"}).json()
    token = client.get(f"/api/v1/attendance/events/{event['id']}/qr-token").json()["token"]

    check_in_response = client.post(
        "/api/v1/attendance/qr-check-ins",
        json={
            "event_id": event["id"],
            "qr_token": token,
            "person_type": "household_person",
            "person_id": dependent["id"],
        },
    )

    assert check_in_response.status_code == 201
    assert check_in_response.json()["person_name"] == "Chris Child"


def test_qr_token_respects_attendance_window() -> None:
    client = build_client()
    people = client.get("/api/v1/members/").json()
    member_id = people["members"][0]["id"]
    event = client.post(
        "/api/v1/attendance/events",
        json={
            "name": "Future Service",
            "qr_opens_at": "2099-01-01T10:00:00Z",
            "qr_closes_at": "2099-01-01T12:00:00Z",
        },
    ).json()

    token_response = client.get(f"/api/v1/attendance/events/{event['id']}/qr-token")

    assert token_response.status_code == 200
    assert token_response.json()["active"] is False
    assert token_response.json()["token"] is None

    check_in_response = client.post(
        "/api/v1/attendance/qr-check-ins",
        json={
            "event_id": event["id"],
            "qr_token": "pcqr1.invalid.1.token",
            "person_type": "member",
            "person_id": member_id,
        },
    )

    assert check_in_response.status_code == 403

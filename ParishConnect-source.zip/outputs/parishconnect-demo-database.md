# ParishConnect Demo Database

## What Was Added

- Docker Compose configuration for local PostgreSQL.
- Safe demo seed script for fake church data.
- SQLite fallback initializer for immediate local presentations.
- DB-backed API endpoints for members, attendance, messages, and stewardship.

## Live Demo

The seeded demo API is running on:

```text
http://127.0.0.1:8002/
```

Useful endpoints:

- `http://127.0.0.1:8002/docs`
- `http://127.0.0.1:8002/api/v1/members/`
- `http://127.0.0.1:8002/api/v1/attendance/`
- `http://127.0.0.1:8002/api/v1/messages/`
- `http://127.0.0.1:8002/api/v1/stewardship/`

## Demo Data

The sample data is fake:

- 1 branch
- 3 members
- 2 visitors
- 2 events
- 4 attendance records
- 2 messages
- 2 contribution records totaling `100000.00 TZS`

## PostgreSQL Note

PostgreSQL is configured through `docker-compose.yml` and has now been started successfully from the normal Windows user session.

Verified PostgreSQL counts:

```text
branches: 1
members: 3
visitors: 2
events: 2
attendance_records: 4
messages: 2
contributions: 2
```

The SQLite demo database remains useful as a fallback, but PostgreSQL is now the preferred local backend database.

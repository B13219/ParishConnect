# ParishConnect Presentation-Ready Skeleton

## Current State

The backend now has a professional application skeleton with:

- FastAPI application entrypoint.
- Browser-friendly landing page at `/`.
- API overview at `/api/v1/`.
- Health check at `/health`.
- Swagger documentation at `/docs`.
- SQLAlchemy database base, session factory, and domain models.
- Alembic migration setup.
- Initial database migration for 11 core tables.
- Docker Compose PostgreSQL service.
- Safe demo seed script using fake member, visitor, attendance, message, and contribution data.
- Tests covering health, product overview, and model registration.

## Core Tables

- `branches`
- `users`
- `roles`
- `user_roles`
- `members`
- `visitors`
- `ministries`
- `events`
- `attendance_records`
- `messages`
- `contributions`

## Demo URLs

When the server is running:

- `http://127.0.0.1:8000/`
- `http://127.0.0.1:8000/docs`
- `http://127.0.0.1:8000/health`
- `http://127.0.0.1:8000/api/v1/`

## Local Database Commands

From the backend folder:

```powershell
docker compose up -d postgres
alembic upgrade head
python -m app.scripts.seed_demo
```

## Verification

The test suite currently passes:

```text
4 passed
```

# ParishConnect Admin Phase

## Added

- Static admin console in `work/parishconnect/frontend`.
- Dashboard cards for members, visitors, attendance, and stewardship.
- Panels for members, visitors, upcoming events, recent messages, and contributions.
- Browser CORS support in the backend for `http://127.0.0.1:5173`.
- Global refresh control plus per-panel refresh controls.
- Loading skeletons, empty states, disabled button states, and stronger mobile wrapping.
- Cleaner responsive behavior for tablet and phone layouts.
- People Management workflow: add member, add visitor, and convert visitor to member.
- Backend People API endpoints for create, update, and conversion.
- Member lifecycle actions for transferred, deceased, and discontinued records.
- People search across name, phone, email, and status.
- Member and visitor status filters.
- Edit dialog for updating member and visitor contact/status details.
- Sticky responsive navigation with active section highlighting while scrolling.
- Attendance workflow: create event/service, manually check in member or visitor, view event totals, and view recent check-ins.
- Household registry workflow: create family households, assign a primary adult, and add children/dependents who cannot self check in.
- QR attendance workflow: event-level QR windows, rotating signed tokens, QR check-in validation, and household/dependent attendance support without GPS.
- Scannable QR display workflow: admin QR SVG display, local scan URL, and mobile-friendly scan check-in page.
- Financial stewardship workflow: record contributions, validate positive amounts, show latest giving records, and monitor totals by contribution type.

## Demo Flow

1. PostgreSQL API on `http://127.0.0.1:8003`.
2. Admin console on `http://127.0.0.1:5173`.
3. Dashboard fetches real seeded data from PostgreSQL-backed API endpoints.

## Verification

```text
backend tests: 18 passed
backend lint: All checks passed
backend compile: OK
frontend page: HTTP 200
frontend script: syntax OK
frontend assets: HTTP 200
CORS preflight: HTTP 200
PostgreSQL API data: verified
encoding scan: OK
people API tests: verified
live member creation: verified
live visitor creation: verified
live visitor conversion: verified
live member transfer status: verified
live visitor edit: verified
people filters UI: added
sticky navigation: verified
attendance API tests: verified
live event creation: verified
live manual check-in: verified
duplicate check-in protection: verified
household migration: applied
household demo seed: verified
live household listing: verified
live household creation: verified
live dependent creation: verified
QR attendance migration: applied
live QR token generation: verified
live QR member check-in: verified
QR SVG endpoint tests: verified
scan page static route: HTTP 200
live QR SVG display: verified
live scan URL page: verified
live scan payload check-in: verified
Docker status command: blocked by local Docker permission state
finance API tests: verified
frontend finance form syntax: verified
sync to promoted project: blocked by current session write permissions
```

Verified dashboard source endpoints:

- `http://127.0.0.1:8003/api/v1/members/`
- `http://127.0.0.1:8003/api/v1/attendance/`
- `http://127.0.0.1:8003/api/v1/members/households`
- `http://127.0.0.1:8003/api/v1/messages/`
- `http://127.0.0.1:8003/api/v1/stewardship/`

People workflow endpoints:

- `POST http://127.0.0.1:8003/api/v1/members/`
- `PATCH http://127.0.0.1:8003/api/v1/members/{member_id}`
- `POST http://127.0.0.1:8003/api/v1/members/visitors`
- `PATCH http://127.0.0.1:8003/api/v1/members/visitors/{visitor_id}`
- `POST http://127.0.0.1:8003/api/v1/members/visitors/{visitor_id}/convert`
- `GET http://127.0.0.1:8003/api/v1/members/households`
- `POST http://127.0.0.1:8003/api/v1/members/households`
- `POST http://127.0.0.1:8003/api/v1/members/households/{household_id}/people`

Attendance workflow endpoints:

- `POST http://127.0.0.1:8003/api/v1/attendance/events`
- `POST http://127.0.0.1:8003/api/v1/attendance/check-ins`
- `GET http://127.0.0.1:8003/api/v1/attendance/events/{event_id}/qr-token`
- `GET http://127.0.0.1:8003/api/v1/attendance/events/{event_id}/qr-code.svg`
- `POST http://127.0.0.1:8003/api/v1/attendance/qr-check-ins`
- `GET http://127.0.0.1:8003/api/v1/attendance/`

Stewardship workflow endpoints:

- `GET http://127.0.0.1:8003/api/v1/stewardship/`
- `POST http://127.0.0.1:8003/api/v1/stewardship/contributions`

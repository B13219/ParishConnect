# ParishConnect Engineering Kickoff

## What We Are Building

ParishConnect is a professional church management and engagement platform that digitizes member records, visitor follow-up, attendance, communication, events, and financial stewardship.

## Recommended Build Strategy

Start with a focused MVP instead of trying to build every module at once.

1. Build the backend data foundation: branches, users, roles, members, visitors, events, attendance, messages, and contributions.
2. Build the admin web app first because staff will manage the most critical workflows.
3. Add QR/manual attendance check-in as the first high-value workflow.
4. Add SMS/push announcements after the people and attendance records are stable.
5. Add contribution recording and reports with strict permissions.
6. Add mobile app and USSD workflows after the API is stable.

## Recommended Stack

| Layer | Choice |
| --- | --- |
| Backend | FastAPI |
| Database | PostgreSQL |
| Admin Web | React with TypeScript |
| Mobile | Flutter or React Native |
| Authentication | JWT/session hybrid with role-based access |
| Messaging | Provider adapters for SMS, USSD, and push |
| Hosting | Cloud VM or managed container platform |

## MVP Milestones

| Phase | Duration | Deliverable |
| --- | ---: | --- |
| 1. Discovery And Setup | 2 weeks | Requirements, data model, repo, environment, UI wireframes |
| 2. Core Backend | 3 weeks | Auth, roles, branches, members, visitors, events |
| 3. Attendance Workflow | 3 weeks | QR/manual check-in, attendance reports |
| 4. Admin Dashboard | 3 weeks | Staff UI for records, events, and reports |
| 5. Messaging | 2 weeks | SMS/push announcements and delivery logs |
| 6. Stewardship | 3 weeks | Contribution records and financial reports |
| 7. Data Migration And Training | 2 weeks | CSV/Excel import, guides, pilot data |
| 8. Pilot And Launch | 2 weeks | Production deployment, monitoring, support |

Estimated MVP duration: 20 weeks.

## Engineering Deliverables Created

- `work/parishconnect/README.md`
- `work/parishconnect/docs/product-requirements.md`
- `work/parishconnect/docs/architecture.md`
- `work/parishconnect/docs/data-model.md`
- `work/parishconnect/docs/api-outline.md`

## First Developer Task

Create the backend API skeleton with:

- FastAPI application entrypoint.
- PostgreSQL connection configuration.
- Alembic migrations.
- Authentication module.
- Branch, user, role, member, visitor, event, and attendance models.
- Health check endpoint.
- Automated tests for health check and basic model validation.


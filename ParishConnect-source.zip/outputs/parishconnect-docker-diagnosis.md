# ParishConnect Docker Diagnosis

## Result

Docker Desktop access from the sandbox was blocked, but PostgreSQL was successfully started from the normal Windows user session.

## Evidence

- Docker CLI is installed.
- Docker Desktop processes are running.
- Docker named pipes exist.
- `com.docker.service` is stopped and cannot be started from the sandbox.
- The active Codex Windows user is `KATANA\codexsandboxoffline`.
- The `docker-users` group contains `KATANA\bekas`, not `KATANA\codexsandboxoffline`.

## Meaning

The issue is not the ParishConnect backend. It is local Docker access from the sandboxed Codex process.

Docker should be tested from the normal Windows user session, not from the sandbox:

```powershell
cd C:\Users\bekas\Documents\Codex\2026-07-10\let\work\parishconnect\backend
.\start-postgres.ps1
```

If Docker still fails from normal PowerShell:

1. Open Docker Desktop manually.
2. Wait until it says the engine is running.
3. Run `docker info`.
4. If it still fails, restart Docker Desktop or reboot Windows.
5. If WSL integration is required, install/repair a WSL2 Linux distribution through Docker Desktop settings or Windows WSL setup.

## Backend Status

The backend is now verified against PostgreSQL on `localhost:5432`.

Verified seed counts:

```text
branches: 1
members: 3
visitors: 2
events: 2
attendance_records: 4
messages: 2
contributions: 2
```

The PostgreSQL-backed API was verified on:

```text
http://127.0.0.1:8003/
```

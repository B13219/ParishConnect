# ParishConnect Product Requirements

## Problem

Churches often manage members, visitors, attendance, offerings, events, and communications using paper registers, spreadsheets, and informal message chains. This creates duplicated data, weak follow-up, slow reporting, and poor visibility for leaders.

## Users

| Role | Primary Needs |
| --- | --- |
| Administrator | Manage users, settings, branches, reports, and system access. |
| Pastor / Leader | View reports, send messages, manage ministries, and follow up with members. |
| Receptionist | Register visitors, update member records, and check attendance. |
| Usher | Mark attendance quickly before, during, or after service. |
| Member | View profile, events, messages, and contribution history. |
| Guest / Visitor | Register, receive follow-up, and become a member when ready. |

## MVP Features

### Registration

- Create visitor records.
- Create member records.
- Convert visitor to member.
- Capture contact details, branch, ministry, and household information.
- Import initial data from Excel or CSV.

### Attendance

- Check in by QR code.
- Check in manually by usher or receptionist.
- Track attendance by service, event, branch, and date.
- Allow authorized post-service corrections.

### Communication

- Send announcements to all members, groups, branches, or ministries.
- Support push notifications, SMS, and in-app messages.
- Store message delivery status where providers support callbacks.

### Events And Ministries

- Create services, events, and ministry meetings.
- Assign members to ministries.
- Track event attendance.

### Stewardship

- Record tithe and offering entries.
- Send reminders.
- Provide member contribution history.
- Produce financial reports for authorized roles.

### Reporting

- Attendance trend reports.
- Visitor follow-up reports.
- Member engagement reports.
- Contribution summaries.
- Data export for administrators.

## Non-Functional Requirements

- Role-based access control.
- Audit trail for sensitive changes.
- Encrypted transport using HTTPS.
- Secure password storage.
- Daily database backups.
- Offline-friendly attendance capture for unreliable internet environments.
- Simple interface for non-technical church staff.

## Out Of Scope For First MVP

- Full accounting system.
- Anonymous giving.
- Advanced AI insights.
- Payroll or HR management.
- Public website builder.

